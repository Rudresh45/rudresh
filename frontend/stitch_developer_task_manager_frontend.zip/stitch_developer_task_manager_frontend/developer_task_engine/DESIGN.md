---
name: Developer Task Engine
colors:
  surface: '#f9f9ff'
  surface-dim: '#d7dae5'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3fe'
  surface-container: '#ebedf9'
  surface-container-high: '#e5e8f3'
  surface-container-highest: '#dfe2ed'
  on-surface: '#181c23'
  on-surface-variant: '#454652'
  inverse-surface: '#2c3039'
  inverse-on-surface: '#eef0fc'
  outline: '#767684'
  outline-variant: '#c6c5d4'
  surface-tint: '#4555b7'
  primary: '#1e3093'
  on-primary: '#ffffff'
  primary-container: '#3949ab'
  on-primary-container: '#bbc3ff'
  inverse-primary: '#bbc3ff'
  secondary: '#006a63'
  on-secondary: '#ffffff'
  secondary-container: '#99efe5'
  on-secondary-container: '#006f67'
  tertiary: '#632d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#863f00'
  on-tertiary-container: '#ffb78a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dee0ff'
  primary-fixed-dim: '#bbc3ff'
  on-primary-fixed: '#000e5e'
  on-primary-fixed-variant: '#2c3c9e'
  secondary-fixed: '#9cf2e8'
  secondary-fixed-dim: '#80d5cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#00504a'
  tertiary-fixed: '#ffdbc7'
  tertiary-fixed-dim: '#ffb689'
  on-tertiary-fixed: '#311300'
  on-tertiary-fixed-variant: '#733500'
  background: '#f9f9ff'
  on-background: '#181c23'
  surface-variant: '#dfe2ed'
typography:
  headline-lg:
    fontFamily: Geist
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.01em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0em
  code-inline:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xxs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system is engineered for developers, technical leads, and engineering professionals who require an uncluttered, high-utility personal task environment. It prioritizes rapid keyboard navigation, dense information architecture, and rigorous clarity over visual ornament.

The emotional baseline is quiet competence, focus, and structural precision. The aesthetic adheres strictly to technical minimalism: razor-sharp 1px dividers, deliberate micro-interactions, distinct monospace accents for syntax and metadata, and an architectural balance of whitespace that maintains high visual density without cognitive friction. There are no luminous gradients, decorative blurs, or skeuomorphic depths; physical cues exist solely to establish semantic hierarchy and interactive affordance.

## Colors

The palette is anchored by deliberate, low-chroma tones built for prolonged terminal and editor-adjacent work.

- **Primary (`#3949AB` - Deep Indigo):** Reserved for primary interactive anchors, focused states, command palette matches, and key task progression states.
- **Secondary (`#0F766E` - Muted Teal):** Applied to success markers, resolved states, issue tracker syncs, and contextual project taxonomies.
- **Background (`#F7F8FA`):** A cool, muted canvas that suppresses eye strain compared to stark white.
- **Surface (`#FFFFFF`):** High-clarity white for active task lists, panels, input bars, and inspector surfaces.
- **Main Text (`#20242C`):** Deep slate-charcoal delivering crisp contrast ratios meeting WCAG AAA across all standard body scales.
- **Secondary Text (`#687180`):** Precise steel gray for timestamps, breadcrumbs, shortcuts, and inactive metadata.
- **Border (`#E5E7EB`):** Crisp, structural containment line for task row dividers, inputs, and layout boundaries.

## Typography

Typography prioritizes information density, numerical tabular alignment, and instant scanability.

- **Geist** serves structural headlines and panel headers, providing strict geometric proportions and tight character spacing.
- **Inter** renders task descriptions, notes, and general UI text to maintain optical balance across compact layouts.
- **JetBrains Mono** governs system metadata, task identifiers (e.g., `DEV-402`), estimates, keyboard hotkeys, tags, and commit hashes. Tabular numbers (`tnum`) must remain enabled across all monospaced elements for alignment in tables and lists.

## Layout & Spacing

The layout model is built around a compact, high-density responsive framework:
- **Desktop (≥ 1024px):** Fixed left navigation rail (240px wide) paired with an elastic central task view (max-width: 960px) and an optional contextual flyout inspector (380px wide). Outer canvas margins use `margin-desktop`, column separations use `gutter-desktop`.
- **Tablet (768px – 1023px):** Collapsed icon-only rail (64px) with a fluid single-panel task stream utilizing `margin` and `gutter`.
- **Mobile (< 768px):** Single-column stacked stream. Secondary panels convert to full-bleed bottom sheets. Outer margin contracts to `margin`.

Component vertical rhythm enforces an 8px base grid, subdivided by 4px and 2px increments (`space-xxs`, `space-xs`) for dense metadata placement within individual task rows.

## Elevation & Depth

Visual hierarchy is communicated through subtle layer boundaries and low-contrast perimeter lines rather than heavy drop shadows:

- **Surface Tier 0 (Background):** `#F7F8FA` application canvas.
- **Surface Tier 1 (Containers & Rows):** `#FFFFFF` cards, rows, and input surfaces bound by a 1px solid `#E5E7EB` border.
- **Surface Tier 2 (Floating Panels & Command Palette):** `#FFFFFF` paired with an ultra-subtle, non-directional shadow: `0px 4px 16px -2px rgba(32, 36, 44, 0.06), 0px 1px 3px 0px rgba(32, 36, 44, 0.04)` combined with a 1px `#E5E7EB` outline.
- **Hover & Active Depth:** Interacting with a task row does not increase elevation; instead, the surface applies a subtle background tint (`#F1F3F5`) with no vertical shift.

## Shapes

The interface embraces a restrained "soft" corner metric:
- **Base Components:** 0.25rem (`4px`) corner radius across inputs, buttons, checkboxes, and inline tags.
- **Panels & Dialogs:** 0.5rem (`8px`) corner radius for command bars, modals, and container shells.
- **Nested Tokens:** Inner elements retain a 2px radius when housed inside 4px containers to preserve proportional geometry. Fully circular pill shapes are avoided to keep the visual tone technical and disciplined.

## Components

### Task Rows
- **Height & Layout:** Compact 36px default height (44px expanded with notes). 
- **Structure:** 1px solid bottom border (`#E5E7EB`), white background. On hover, background shifts to `#F7F8FA`.
- **Content Flow:** Checkbox → Monospace ID (`JetBrains Mono`, `#687180`) → Task Title (`Inter`, `#20242C`) → Secondary Tags (`#0F766E` / neutral tint) → Due Date / Shortcut cues (`#687180`).

### Checkboxes
- **Geometry:** 16px × 16px with a 3px radius.
- **Resting:** 1.5px solid `#D1D5DB`, background transparent.
- **Checked:** Solid `#3949AB` fill with a sharp white checkmark (stroke width 1.75px). 
- **Focus:** 2px ring offset in `#3949AB` with 1px white separation.

### Buttons
- **Primary:** Background `#3949AB`, text `#FFFFFF`, height 32px, horizontal padding 12px, border-radius 4px. Hover: `#303F9F`.
- **Secondary / Outline:** Background `#FFFFFF`, 1px solid `#E5E7EB`, text `#20242C`. Hover: `#F7F8FA`, border `#D1D5DB`.
- **Ghost / Icon:** 28px × 28px square, transparent background, text `#687180`. Hover: background `#ECEEF1`, text `#20242C`.

### Chips & Badges
- **Tag Badge:** Height 20px, font `JetBrains Mono` 11px, radius 3px. Padding: 2px 6px.
- **Color Scheme:** Neutral (`#F1F3F5` background, `#20242C` text, `#E5E7EB` border). Technical tags (e.g. `refactor`, `bug`) use secondary muted teal (`#F0FDFA` background, `#0F766E` text, `#CCFBF1` border).

### Input Fields
- **Height & Typography:** 32px height, font `Inter` 13px, horizontal padding 8px.
- **Borders & State:** 1px solid `#E5E7EB`, background `#FFFFFF`. Focus: border color `#3949AB`, with zero spread/blur shadows. Placeholder: `#9CA3AF`.

### Command Palette (K-Bar)
- **Dimensions:** Max-width 560px, centered horizontally at top 15% viewport.
- **Styling:** Tier 2 elevation, `#FFFFFF` surface, 1px `#E5E7EB` outline, 8px radius.
- **Items:** 36px height per item, selected item uses `#F1F3F5` with a left 2px `#3949AB` indicator mark. Keyboard shortcuts displayed on trailing edge in `JetBrains Mono` 11px inside a 1px border keycap.